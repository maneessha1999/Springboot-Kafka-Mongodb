package com.rajeshkawali;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootMongoKafkaProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
